package com.bses.dinesh.dsk.telematics.interfaces;

public interface ClickEventValue {
    public void onClickValue(String value);
}
