package com.bses.dinesh.dsk.telematics.utils;

import android.location.Location;

public interface LiveLocationUpdate {
    void onLocation(Location location);
}
