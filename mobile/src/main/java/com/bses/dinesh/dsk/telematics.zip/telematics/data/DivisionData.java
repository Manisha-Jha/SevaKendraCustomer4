package com.bses.dinesh.dsk.telematics.data;

public class DivisionData {
    private String id;
    private String name;

    public DivisionData() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
