package com.bses.dinesh.dsk.telematics.interfaces;

public interface ClickEventPosValue {
    public void onClickPosValue(String value, int pos);
}
